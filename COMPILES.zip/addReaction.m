% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    addReaction                                                            %
%                                                                           %
%                                                                           %
% OUTPUT: Returns a structure called 'model' with added field 'reaction'    %
%    with subfields 'id', 'reactant', 'product', 'reversible', and          %
%    'kinetic' (see README.txt for details). The output variable 'model'    %
%    allows the user to view the network with the added reaction.           %
%                                                                           %
% INPUTS:                                                                   %
%    - model: a structure, representing the chemical reaction network (CRN) %
%         (see README.txt for details on how to fill out the structure)     %
%    - id: visual representation of the reaction, e.g., reactant -> product %
%         (string)                                                          %
%    - reactant_species: species of the reactant complex (cell)             %
%    - reactant_stoichiometry: stoichiometry of the species of the reactant %
%         complex (cell)                                                    %
%    - reactant_kinetic: kinetic orders of the species of the reactant      %
%         complex (array)                                                   %
%    - product_species: species of the product complex (cell)               %
%    - product_stoichiometry: stoichiometry of the species of the product   %
%         complex (cell)                                                    %
%    - product_kinetic: "kinetic orders" of the species of the product      %
%         complex, if the reaction is reversible (array)                    %
%    - reversible: logical; whether the reaction is reversible or not (true %
%         or false)                                                         %
%                                                                           %
% Note: This code is developed to make the input of reactions of the CRN    %
%    easier than the input in Soranzo and Altafini (2009).                  %
%                                                                           %
% Reference: Soranzo N, Altafini C (2009) ERNEST: a toolbox for chemical    %
%    reaction network theory. Bioinform 25(21):2853–2854.                   %
%    https://doi.org/10.1093/bioinformatics/btp513                          %
%                                                                           %
% Created: 13 July 2022                                                     %
% Last Modified: 13 July 2022                                               %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



function model = addReaction(model, id, reactant_species, reactant_stoichiometry, reactant_kinetic, product_species, product_stoichiometry, product_kinetic, reversible)

    % For succeeding reactions
    try
        model.reaction(end+1) = struct('id', id, 'reactant', struct('species', reactant_species, 'stoichiometry', reactant_stoichiometry), 'product', struct('species', product_species, 'stoichiometry', product_stoichiometry), 'reversible', reversible, 'kinetic', struct('reactant1', reactant_kinetic, 'reactant2', product_kinetic));
    
    % For the first reaction
    catch
        model.reaction(1) = struct('id', id, 'reactant', struct('species', reactant_species, 'stoichiometry', reactant_stoichiometry), 'product', struct('species', product_species, 'stoichiometry', product_stoichiometry), 'reversible', reversible, 'kinetic', struct('reactant1', reactant_kinetic, 'reactant2', product_kinetic));
    end

end