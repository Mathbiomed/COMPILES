% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 4                                                              %
%                                                                           %
%                                                                           %
% This is Example 1 in Hernandez et al (2022): Subnetworks 1 and 2 of the   %
%    zigzag model of plant-pathogen interactions                            %
%                                                                           %
% RESULT: The network has 2 subnetworks. The steady state of species X1 and %
%    X3 are parametrized in terms of the rate constants and the free        %
%    parameters X2, X4, and X5. There are 3 conservation laws.              %
%                                                                           %
% Reference: Hernandez B, Lubenia P, Johnston M, Kim J (2022) Deriving      %
%    analytic positive steady states of chemical reaction systems via       %
%    network decomposition and network translation (in preparation)         %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 4';
model = addReaction(model, 'X1+X2<->X3', ...              % just a visual guide on how the reaction looks like
                           {'X1', 'X2'}, {1, 1}, [1], ... % reactant species, stoichiometry, kinetic order
                           {'X3'}, {1}, [1], ...          % product species, stoichiometry, "kinetic order" (if reversible)
                           true);                         % reversible or not
model = addReaction(model, 'X3->X3+X4', ...
                           {'X3'}, {1}, [1], ...
                           {'X3', 'X4'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'X4->0', ...
                           {'X4'}, {1}, [1], ...
                           { }, { }, [ ], ...
                           false);
model = addReaction(model, 'X4+X5->X5', ...
                           {'X4', 'X5'}, {1, 1}, [1], ...
                           {'X5'}, {1}, [ ], ...
                           false);

% Generate the parametrized steady steady solution
[equation, species, free_parameter, conservation_law, model] = steadyState(model);