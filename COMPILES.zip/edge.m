% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    edge                                                                     %
%                                                                             %
%                                                                             %
% OUTPUT: Returns a directed edge with indicated starting and ending vertex   %
%            numbers. It adds a directed edge from 'from_node' to 'to_node'   %
%            to a directed graph created using the class graph_.              %
% INPUTS:                                                                     %
%         - from_node: starting vertex number (natural number)                %
%         - to_node: ending vertex number (natural number)                    %
%                                                                             %
% Notes:                                                                      %
%    1. This class was converted from Python to Matlab.                       %
%    2. Python code can be found in https://github.com/ricelink/finding-all-  %
%          spanning-trees-in-directed-graph.                                  %
%                                                                             %
% Reference: Gabow H and Meyers E (1978) Finding all spanning trees of        %
%    and undirected graphs. SIAM J Comput 7(3):280-287.                       %
%    https://doi.org/10.1137/0207024                                          %
%                                                                             %
% Created: 21 June 2022                                                       %
% Last Modified: 4 July 2022                                                  %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

classdef edge

    % Container of the nodes (with default values)
    properties
        from_node = 1 % Starting vertex
        to_node = 1   % Ending vertex
    end

    % Allows us to input starting and ending nodes in 'edge'
    methods
        function output = edge(from_node, to_node)

            % A proper edge is created if you input two values in 'edge'
            % If it's just 'edge()', it will create the default 'edge(1, 1)'
            if nargin > 0
                output.from_node = from_node;
                output.to_node = to_node;
            end
        end
    end
end