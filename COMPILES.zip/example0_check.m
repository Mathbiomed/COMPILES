% Clear all variables
clear all

% Define the symbols
syms k1 k2 k3 k4 k5 k6
syms A B C D
syms sigma1

% Fluxes
v1 = k1*A*C;
v2 = k2;
v3 = k3*A;
v4 = k4*B*C;
v5 = k5*B;
v6 = k6*D;

% ODEs
odeA = -v1 + v2 - v3 + v3;
odeB = -v4 + v4 - v5 + v6;
odeC = -v1 + v3 - v4;
odeD = v5 - v6;

% Solution
A = (k2 + sigma1)/k3;
B = (k1*sigma1*(k2 + sigma1))/(k2*k3*k4);
C = (k2*k3)/(k1*(k2 + sigma1));
D = (k1*k5*sigma1*(k2 + sigma1))/(k2*k3*k4*k6);

% Check
checkA = simplify(subs(odeA))
checkB = simplify(subs(odeB))
checkC = simplify(subs(odeC))
checkD = simplify(subs(odeD))